export interface ReenactmentGroup {
  name: string;
  description: string;
  website: string;
  location: string;
  period: string;
}
export interface Trader {
  name: string;
  description: string;
  website: string;
  specialties: string[];
}
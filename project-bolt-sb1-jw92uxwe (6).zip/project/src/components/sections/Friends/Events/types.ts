export interface FriendEvent {
  name: string;
  organizer: string;
  date: string;
  location: string;
  description: string;
  website: string;
}
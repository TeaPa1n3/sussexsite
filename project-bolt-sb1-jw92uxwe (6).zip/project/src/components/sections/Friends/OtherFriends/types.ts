export interface OtherFriend {
  name: string;
  description: string;
  website: string;
  category: string;
}
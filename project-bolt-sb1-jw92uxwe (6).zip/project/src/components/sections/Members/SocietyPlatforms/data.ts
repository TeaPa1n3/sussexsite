export const platforms = [
  {
    title: "SMS WhatsApp Community",
    description: "Space for logistics, organisation and sharing event information.",
    url: "https://chat.whatsapp.com/GJPOmqAm0fDFAtJ67XAPZk",
    size: "WhatsApp Group",
    category: "WhatsApp Group"
  },
    {
    title: "Discord Group",
    description: "Space for shenanigans, banter, memes and sharing hobby/crafting knowledge.",
    url: "http://discord.gg/QdbRPy3uCD",
    size: "Discord Group",
    category: "Discord Group"
  }
];
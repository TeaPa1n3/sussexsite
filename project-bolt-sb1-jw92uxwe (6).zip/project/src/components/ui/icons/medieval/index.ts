import { CombatIcon } from './CombatIcon';
import { TentIcon } from './TentIcon';
import { ShieldIcon } from './ShieldIcon';
import { SwordIcon } from './SwordIcon';
import { AxeIcon } from './AxeIcon';
import { ScrollIcon } from './ScrollIcon';
import { ArmorIcon } from './ArmorIcon';
import { CrownIcon } from './CrownIcon';

export {
  CombatIcon,
  TentIcon,
  
  
  
  
  
  
};